

import java.util.Scanner;

public class FloatingpointComparison {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first floating-point number: ");
        double num1 = scanner.nextDouble();

        System.out.print("Enter second floating-point number: ");
        double num2 = scanner.nextDouble();

        if (areAlmostEqual(num1, num2, 3)) {
            System.out.println(num1 + " and "+num2+ " are equal up to three decimal places.");
        } else {
            System.out.println(num1 + " and "+num2+ " are not equal up to three decimal places.");
        }
        scanner.close();
    }
    public static boolean areAlmostEqual(double num1, double num2, int precision) {
        double epsilon = Math.pow(10,-precision);
        return Math.abs(num1-num2)<epsilon;
    }
}
