import java.util.Scanner;

public class NumberOrderChecker {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Three Numbers:");
        double num1 = scanner.nextDouble();
        double num2 = scanner.nextDouble();
        double num3 = scanner.nextDouble();

        String order = checkOrder(num1, num2, num3);
        System.out.println(order);
        scanner.close();}

    public static String checkOrder(double num1, double num2, double num3) {
        if (num1<num2 && num2<num3) {
            return "Increasing";
        } else if (num1>num2 && num2>num3) {
            return "Decreasing";
        } else {
            return "Neither increasing nor decreasing order";
        }
    }
}
