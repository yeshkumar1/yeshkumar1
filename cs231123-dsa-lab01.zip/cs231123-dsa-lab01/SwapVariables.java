public class SwapVariables {
    int x;
    int y;
    public SwapVariables(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public void swap() {
        x = x + y;
        y = x - y;
        x = x - y;
    }
    public static void main(String[] args) {
        SwapVariables swap = new SwapVariables(5, 10);
        System.out.println("Before swap:x= "+swap.x+ ",y= "+swap.y);
        swap.swap();
        System.out.println("After swap:x="+swap.x +",y="+swap.y);
    }
}
