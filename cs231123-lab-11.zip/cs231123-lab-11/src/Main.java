
class Vertex {
    char label;
    boolean visited;
    Vertex(char label) {
        this.label = label;
        this.visited = false;
    }
}

class Graph {
    private final int MAX_VERTICES = 20;
    private Vertex[] vertices;
    private int[][] adjMatrix;
    private int vertexCount;

    Graph() {
        vertices = new Vertex[MAX_VERTICES];
        adjMatrix = new int[MAX_VERTICES][MAX_VERTICES];
        vertexCount = 0;
        for (int i = 0; i < MAX_VERTICES; i++) {
            for (int j = 0; j < MAX_VERTICES; j++) {
                adjMatrix[i][j] = 0;
            }
        }
    }
    void addVertex(char label) {
        vertices[vertexCount++] = new Vertex(label);
    }
    void addEdge(int start, int end) {
        adjMatrix[start][end] = 1;
        adjMatrix[end][start] = 1; // For undirected graph
    }
    void displayVertex(int v) {
        System.out.print(vertices[v].label + " ");
    }
    void calculateDegrees() {
        System.out.println("Node Degrees:");
        for (int i = 0; i < vertexCount; i++) {
            int degree = 0;
            for (int j = 0; j < vertexCount; j++) {
                if (adjMatrix[i][j] == 1) {
                    degree++;
                }
            }
            System.out.println(vertices[i].label + ": " + degree);
        }
    }
}
public class Main {
    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.addVertex('A');
        graph.addVertex('B');
        graph.addVertex('C');
        graph.addVertex('D');
        graph.addVertex('E');
         graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 3);
        graph.addEdge(2, 3);
        graph.addEdge(3, 4);
        graph.calculateDegrees();
    }
}
