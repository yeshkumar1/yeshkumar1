import java.util.*;

class DirectedGraph {
    private final int MAX_VERTICES = 20;
    private Vertex[] vertices;
    private int[][] adjMatrix;
    private int vertexCount;

    DirectedGraph() {
        vertices = new Vertex[MAX_VERTICES];
        adjMatrix = new int[MAX_VERTICES][MAX_VERTICES];
        vertexCount = 0;

        for (int i = 0; i < MAX_VERTICES; i++) {
            for (int j = 0; j < MAX_VERTICES; j++) {
                adjMatrix[i][j] = 0;
            }
        }
    }

    void addVertex(char label) {
        vertices[vertexCount++] = new Vertex(label);
    }

    void addEdge(int start, int end) {
        adjMatrix[start][end] = 1; // Directed edge
    }

    void displayVertex(int v) {
        System.out.print(vertices[v].label + " ");
    }
    void breadthFirstTraversal() {
        Queue<Integer> queue = new LinkedList<>();
        vertices[0].visited = true;
        displayVertex(0);
        queue.add(0);

        while (!queue.isEmpty()) {
            int currentVertex = queue.poll();
            int neighbor;

            while ((neighbor = getUnvisitedNeighbor(currentVertex)) != -1) {
                vertices[neighbor].visited = true;
                displayVertex(neighbor);
                queue.add(neighbor);
            }
        }
        resetVisited();
    }
    void depthFirstTraversal() {
        Stack<Integer> stack = new Stack<>();
        vertices[0].visited = true;
        displayVertex(0);
        stack.push(0);

        while (!stack.isEmpty()) {
            int currentVertex = stack.peek();
            int neighbor = getUnvisitedNeighbor(currentVertex);

            if (neighbor == -1) {
                stack.pop();
            } else {
                vertices[neighbor].visited = true;
                displayVertex(neighbor);
                stack.push(neighbor);
            }
        }
        resetVisited();
    }

    private int getUnvisitedNeighbor(int vertex) {
        for (int i = 0; i < vertexCount; i++) {
            if (adjMatrix[vertex][i] == 1 && !vertices[i].visited) {
                return i;
            }
        }
        return -1;
    }
    private void resetVisited() {
        for (int i = 0; i < vertexCount; i++) {
            vertices[i].visited = false;
        }
    }
}

// Main class
public class mainn {
    public static void main(String[] args) {
        DirectedGraph graph = new DirectedGraph();

        // Add vertices
        graph.addVertex('A');
        graph.addVertex('B');
        graph.addVertex('C');
        graph.addVertex('D');
        graph.addVertex('E');
        graph.addEdge(0, 1); // A->B
        graph.addEdge(0, 2); // A->C
        graph.addEdge(1, 3); // B->D
        graph.addEdge(2, 3); // C->D
        graph.addEdge(3, 4); // D->E

        System.out.println("BFS Traversal:");
        graph.breadthFirstTraversal();
        System.out.println("\nDFS Traversal:");
        graph.depthFirstTraversal();
    }
}
