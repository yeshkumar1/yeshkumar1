import java.util.Scanner;
class Node{
    String data;
    Node prev;
    Node next;
    public Node(String data){
        this.data =data;
        this.prev =null;
        this.next =null;}}
class DoublyLinkedList{
    Node head;
    Node tail;

    public DoublyLinkedList(){
        head =null;
        tail =null;
    }
    public void insertAtEnd(String data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }
    public void deleteNode(String data) {
        Node current =head;
        while (current !=null) {
            if (current.data.equals(data)) {
                if (current ==head) {
                    head =current.next;
                    if (head !=null) {
                        head.prev =null;
                    }
                } else if (current ==tail) {
                    tail =current.prev;
                    if (tail !=null) {
                        tail.next =null;
                    }
                } else {
                    current.prev.next =current.next;
                    current.next.prev =current.prev;
                }
                break;
            }
            current =current.next;
        }}
    public void modifyNode(String oldData, String newData) {
        Node current =head;
        while (current !=null) {
            if (current.data.equals(oldData)) {
                current.data =newData;
                break;
            }
            current =current.next;
        }
    }
    public void display() {
        Node current =head;
        while (current !=null) {
            System.out.print(current.data);
            current =current.next;}
        System.out.println();
    }}
public class TextEditor {
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        DoublyLinkedList text =new DoublyLinkedList();

        while (true) {
            System.out.println("\n1.insert Text");
            System.out.println("2.delete Text");
            System.out.println("3.modify Text");
            System.out.println("4.display Text");
            System.out.println("5.exit");
            System.out.print("enter your choice:");
            int choice =scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    System.out.print("enter text to insert: ");
                    String insertText = scanner.nextLine();
                    text.insertAtEnd(insertText);
                    break;
                case 2:
                    System.out.print("enter text to delete: ");
                    String deleteText = scanner.nextLine();
                    text.deleteNode(deleteText);
                    break;
                case 3:
                    System.out.print("enter text to modify: ");
                    String oldText = scanner.nextLine();
                    System.out.print("enter new text: ");
                    String newText = scanner.nextLine();
                    text.modifyNode(oldText, newText);
                    break;
                case 4:
                    System.out.println("current Text:");
                    text.display();
                    break;
                case 5:
                    System.out.println("exiting...");
                    System.exit(0);
                default:
                    System.out.println("invalid choice.");
            }
        }}}