class CircularLinkedList{
    private Node last;
    private static class Node{
        int data;
        Node next;

        Node(int data){
            this.data =data;
            next =null;
        }}
    public CircularLinkedList() {
        last =null;
    }
    public void traverse() {
        if (last ==null) {
            System.out.println("List is empty.");
            return;
        }
        Node temp =last.next;
        do {
            System.out.print(temp.data+ " ");
            temp =temp.next;
        } while (temp !=last.next);
        System.out.println();
    }
    public void insertAtHead(int data) {
        Node newNode =new Node(data);
        if (last ==null) {
            last =newNode;
            last.next =last;
        } else {
            newNode.next =last.next;
            last.next =newNode;
        }}
    public void insertAfterNode(int target, int data) {
        if (last ==null) {
            System.out.println("list is empty.cannot insert.");
            return;
        }
        Node temp =last.next;
        do {
            if (temp.data ==target) {
                Node newNode =new Node(data);
                newNode.next =temp.next;
                temp.next =newNode;
                if (temp ==last) {
                    last =newNode;}
                return;
            }
            temp =temp.next;
        } while (temp !=last.next);
        System.out.println("target node not found.");
    }
    public void insertAtEnd(int data) {
        Node newNode =new Node(data);
        if (last ==null) {
            last =newNode;
            last.next =last;
        } else {
            newNode.next =last.next;
            last.next =newNode;
            last =newNode;
        }
    }
    public void deleteHead() {
        if (last ==null) {
            System.out.println("list is empty. cannot delete.");
            return;
        }
        if (last.next ==last) {
            last= null;
        } else {
            last.next =last.next.next;
        }
    }
    public void deleteEnd() {
        if (last== null) {
            System.out.println("list is empty.cannot delete.");
            return;}
        if (last.next ==last) {
            last =null;
        } else {
            Node temp =last.next;
            while (temp.next !=last) {
                temp =temp.next;
            }
            temp.next =last.next;
            last =temp;
        }
    }
    public void deleteAtPosition(int position) {
        if (last ==null) {
            System.out.println("list is empty.cannot delete.");
            return;
        }
        if (position== 1) {
            deleteHead();
            return;
        }
        Node temp= last.next;
        Node prev =null;
        int count =1;
        do {
            if (count ==position) {
                prev.next =temp.next;
                if (temp ==last) {
                    last =prev;
                }
                return;
            }
            prev =temp;
            temp= temp.next;
            count++;
        } while (temp != last.next);
        System.out.println("invalid position.");
    }
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();
        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        list.insertAtHead(5);
        list.traverse();
        list.insertAfterNode(10, 15);
        list.traverse();
        list.deleteHead();
        list.traverse();
        list.deleteEnd();
        list.traverse();
        list.deleteAtPosition(2);
        list.traverse();
    }
}
